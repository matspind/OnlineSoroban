document.addEventListener("DOMContentLoaded", function() {
    let calculationInterval = 5000; // Default interval is 5 seconds
    let calculationIndex = 0;
    let interval;
    let currentSum = 0;
    let calculations = [];
    let finalResult = 0; // To store the final result

    // Select all rods
    const rods = document.querySelectorAll('.rod');

    // Function to update the count based on bead positions
    function updateCount() {
        rods.forEach((rod, rodIndex) => {
            const upperBead = rod.querySelector('.upper-bead');
            const lowerBeads = rod.querySelectorAll('.lower-bead');
            const countBox = document.getElementById(`count${rodIndex + 1}`);
            let count = 0;

            // Add 5 if the upper bead is down (active)
            if (upperBead.classList.contains('active')) {
                count += 5;
            }

            // Add 1 for each lower bead that is up (active)
            lowerBeads.forEach(bead => {
                if (bead.classList.contains('active')) {
                    count += 1;
                }
            });

            // Update the count box with the current count
            countBox.textContent = count;
        });
    }

    // Add click event to each bead
    rods.forEach((rod, rodIndex) => {
        const upperBead = rod.querySelector('.upper-bead');
        const lowerBeads = rod.querySelectorAll('.lower-bead');

        upperBead.addEventListener('click', function() {
            upperBead.classList.toggle('active');
            updateCount();
        });

        lowerBeads.forEach((bead, index) => {
            bead.addEventListener('click', function() {
                if (!bead.classList.contains('active')) {
                    for (let i = 0; i <= index; i++) {
                        lowerBeads[i].classList.add('active');
                    }
                } else {
                    for (let i = index; i < lowerBeads.length; i++) {
                        lowerBeads[i].classList.remove('active');
                    }
                }
                updateCount();
            });
        });
    });

    // ---- START BUTTON LOGIC ----
    
    // Function to generate a valid random number that keeps the sum between 0 and +4
    function generateRandomNumber(currentSum) {
        const possibleNumbers = [+1, -1, +2, -2, +3, -3, +4, -4];
        let randomNumber;

        // Keep generating random numbers until a valid one is found
        do {
            randomNumber = possibleNumbers[Math.floor(Math.random() * possibleNumbers.length)];
        } while ((currentSum + randomNumber) < 0 || (currentSum + randomNumber) > 4);

        return randomNumber;
    }

    const startButton = document.getElementById('startButton');
    const startButton2 = document.getElementById('startButton2');
    const calculationDisplay = document.getElementById('calculation');
    const resultDisplay = document.getElementById('result');

    // Function to format and show the next calculation with "+" for positive numbers
    function showNextCalculation() {
        if (calculationIndex < calculations.length) {
            const number = calculations[calculationIndex];
            calculationDisplay.textContent = (number > 0 ? `+${number}` : `${number}`);
            currentSum += number; // Update the sum
            calculationIndex++; // Move to the next number
        } else {
            clearInterval(interval); // Stop the regular interval once all numbers are shown
            setTimeout(() => {
                calculationDisplay.textContent = "Finished!"; // Show "Finished!" after a 3-second delay
                resultDisplay.textContent = `Result: ${currentSum}`; // Display the final result
            }, 3000); // Wait 3 seconds before showing "Finished!" and result
        }
    }

    // Event listener for the start buttons to begin the calculations
    function startCalculations() {
        calculationIndex = 0; // Reset index
        currentSum = 0; // Reset sum
        finalResult = 0; // Reset final result
        calculationDisplay.textContent = "Get Ready...";
        resultDisplay.textContent = "Result: ";
        calculations = [];

        // Generate 4 random numbers that keep the sum within 0 to +4
        for (let i = 0; i < 4; i++) {
            const randomNumber = generateRandomNumber(currentSum);
            calculations.push(randomNumber);
            currentSum += randomNumber;
        }

        currentSum = 0;

        // Clear any existing interval
        if (interval) {
            clearInterval(interval);
        }

        // Show the first calculation after a delay, then continue showing numbers based on the selected interval
        setTimeout(() => {
            interval = setInterval(showNextCalculation, calculationInterval);
            showNextCalculation();
        }, calculationInterval);
    }

    startButton.addEventListener('click', startCalculations);
    startButton2.addEventListener('click', startCalculations);

    // ---- SPEED BUTTON LOGIC ----
    
    // Function to update the speed based on the selected button
    function setSpeed(speed) {
        calculationInterval = speed;
        document.querySelectorAll('.speed-button').forEach(button => {
            button.classList.remove('selected');
        });
        document.querySelector(`#speed${speed / 1000}`).classList.add('selected');
    }

    // Add event listeners for the speed buttons
    document.getElementById('speed5').addEventListener('click', function() {
        setSpeed(5000); // Set interval to 5 seconds
    });
    document.getElementById('speed3').addEventListener('click', function() {
        setSpeed(3000); // Set interval to 3 seconds
    });
    document.getElementById('speed1').addEventListener('click', function() {
        setSpeed(1000); // Set interval to 1 second
    });

    // ---- RESET BUTTON LOGIC ----
    
    // Function to reset the Soroban (deactivate all beads and reset counts)
    function resetSoroban() {
        rods.forEach((rod, rodIndex) => {
            const upperBead = rod.querySelector('.upper-bead');
            const lowerBeads = rod.querySelectorAll('.lower-bead');
            const countBox = document.getElementById(`count${rodIndex + 1}`);

            // Remove active class from all beads
            upperBead.classList.remove('active');
            lowerBeads.forEach(bead => {
                bead.classList.remove('active');
            });

            // Reset the count to 0
            countBox.textContent = '0';
        });

        // Reset result and calculation display
        document.getElementById('calculation').textContent = "Get Ready...";
        document.getElementById('result').textContent = "Result: ";
    }

    // Add event listener for the Reset button
    const resetButton = document.getElementById('resetButton');
    resetButton.addEventListener('click', resetSoroban);
});
